﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Unity.VisualScripting;

public class InventoryManager : MonoBehaviour
{
    public Transform inventoryContent;
    public GameObject inventoryItemPrefab;
    public TMP_Text selectedTotalText;

    public void AddWeapon(WeaponData weapon)
    {
        GameObject itemObj = Instantiate(inventoryItemPrefab, inventoryContent);
        InventoryItem item = itemObj.GetComponent<InventoryItem>();
        
        if (item != null)
        {
            item.Setup(weapon, this);
        }

        LayoutRebuilder.ForceRebuildLayoutImmediate(inventoryContent.GetComponent<RectTransform>());
    }
    public void RemoveWeapon(WeaponData data)
    {
        foreach (Transform child in inventoryContent)
        {
            InventoryItem item = child.GetComponent<InventoryItem>();
            if (item != null && item.GetData().weaponName == data.weaponName)
            {
                Destroy(child.gameObject);
                break;
            }
        }

        LayoutRebuilder.ForceRebuildLayoutImmediate(inventoryContent.GetComponent<RectTransform>());
    }
    public void RemoveSelectedItems()
    {
        List<GameObject> toRemove = new List<GameObject>();

        foreach (Transform child in inventoryContent)
        {
            InventoryItem item = child.GetComponent<InventoryItem>();
            if (item != null && item.IsSelected())
            {

                Debug.Log("IsSelected() pass");
                toRemove.Add(child.gameObject);
            }
        }

        foreach (GameObject obj in toRemove)
        {
            Destroy(obj);
        }

        LayoutRebuilder.ForceRebuildLayoutImmediate(inventoryContent.GetComponent<RectTransform>());
    }
    public void UpdateSelectedTotal()
    {
        int total = 0;

        foreach (Transform child in inventoryContent)
        {
            InventoryItem item = child.GetComponent<InventoryItem>();
            if (item != null && item.IsSelected())
            {
                total += item.GetTotalPrice(); // ✅ 안전한 방식      
            }
        }

        selectedTotalText.text = "Selected Total: $" + total.ToString();
    }
}
