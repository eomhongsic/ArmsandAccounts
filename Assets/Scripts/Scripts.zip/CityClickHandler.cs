﻿using UnityEngine;

public class CityClickHandler : MonoBehaviour
{
    public string cityName;
    public WarehouseUIManager warehouseUIManager;
    public GameObject warehousePanel; // ✅ 패널 직접 제어

    public void OnCityClicked()
    {
        var data = WarehouseManager.Instance.GetWarehouseByCity(cityName);

        if (data != null)
        {
            warehousePanel.SetActive(true); // ✅ 패널 열기
            warehouseUIManager.ShowWarehouseContents(data);
            Debug.Log($"{cityName} 창고 표시됨, 보유 무기: {data.storedWeapons.Count}개");
        }
        else
        {
            Debug.LogWarning($"{cityName} 창고 없음");
        }
    }
}